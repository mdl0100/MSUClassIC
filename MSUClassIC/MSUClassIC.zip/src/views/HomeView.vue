<script setup>
import Login from '../components/Login.vue'
import Site from '../components/Site.vue'

</script>

<template>
  
</template>


<style>
h1 {
  display: flex;
  justify-content: center;
  height: 100vh;
  font-size: 2rem;
  color: #02bd7e;
}
</style>