
<template>
  <div class="about">
    <h3>MSUClassIC helps you figure out  <br /> 
     your department's classes schedule</h3>
  </div>
</template>

<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: inline-block ;
    text-align: center;
    align-items: center;
    width: 100%;
  }
}
</style>
